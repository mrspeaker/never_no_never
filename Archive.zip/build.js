(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
"use strict";

var _Game = require("./src/Game");

var _Game2 = _interopRequireDefault(_Game);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

new _Game2.default();

},{"./src/Game":11}],2:[function(require,module,exports){
/**
*   EasyStar.js
*   github.com/prettymuchbryce/EasyStarJS
*   Licensed under the MIT license.
* 
*   Implementation By Bryce Neal (@prettymuchbryce)
**/

var EasyStar = {}
var Instance = require('./instance');
var Node = require('./node');
var Heap = require('heap');

const CLOSED_LIST = 0;
const OPEN_LIST = 1;

module.exports = EasyStar;

EasyStar.js = function() {
    var STRAIGHT_COST = 1.0;
    var DIAGONAL_COST = 1.4;
    var syncEnabled = false;
    var pointsToAvoid = {};
    var collisionGrid;
    var costMap = {};
    var pointsToCost = {};
    var allowCornerCutting = true;
    var iterationsSoFar;
    var instances = [];
    var iterationsPerCalculation = Number.MAX_VALUE;
    var acceptableTiles;
    var diagonalsEnabled = false;

    /**
    * Sets the collision grid that EasyStar uses.
    * 
    * @param {Array|Number} tiles An array of numbers that represent 
    * which tiles in your grid should be considered
    * acceptable, or "walkable".
    **/
    this.setAcceptableTiles = function(tiles) {
        if (tiles instanceof Array) {
            // Array
            acceptableTiles = tiles;
        } else if (!isNaN(parseFloat(tiles)) && isFinite(tiles)) {
            // Number
            acceptableTiles = [tiles];
        }
    };

    /**
    * Enables sync mode for this EasyStar instance..
    * if you're into that sort of thing.
    **/
    this.enableSync = function() {
        syncEnabled = true;
    };

    /**
    * Disables sync mode for this EasyStar instance.
    **/
    this.disableSync = function() {
        syncEnabled = false;
    };

    /**
     * Enable diagonal pathfinding.
     */
    this.enableDiagonals = function() {
        diagonalsEnabled = true;
    }

    /**
     * Disable diagonal pathfinding.
     */
    this.disableDiagonals = function() {
        diagonalsEnabled = false;
    }

    /**
    * Sets the collision grid that EasyStar uses.
    * 
    * @param {Array} grid The collision grid that this EasyStar instance will read from. 
    * This should be a 2D Array of Numbers.
    **/
    this.setGrid = function(grid) {
        collisionGrid = grid;

        //Setup cost map
        for (var y = 0; y < collisionGrid.length; y++) {
            for (var x = 0; x < collisionGrid[0].length; x++) {
                if (!costMap[collisionGrid[y][x]]) {
                    costMap[collisionGrid[y][x]] = 1
                }
            }
        }
    };

    /**
    * Sets the tile cost for a particular tile type.
    *
    * @param {Number} The tile type to set the cost for.
    * @param {Number} The multiplicative cost associated with the given tile.
    **/
    this.setTileCost = function(tileType, cost) {
        costMap[tileType] = cost;
    };

    /**
    * Sets the an additional cost for a particular point.
    * Overrides the cost from setTileCost.
    *
    * @param {Number} x The x value of the point to cost.
    * @param {Number} y The y value of the point to cost.
    * @param {Number} The multiplicative cost associated with the given point.
    **/
    this.setAdditionalPointCost = function(x, y, cost) {
        pointsToCost[x + '_' + y] = cost;
    };

    /**
    * Remove the additional cost for a particular point.
    *
    * @param {Number} x The x value of the point to stop costing.
    * @param {Number} y The y value of the point to stop costing.
    **/
    this.removeAdditionalPointCost = function(x, y) {
        delete pointsToCost[x + '_' + y];
    }

    /**
    * Remove all additional point costs.
    **/
    this.removeAllAdditionalPointCosts = function() {
        pointsToCost = {};
    }

    /**
    * Sets the number of search iterations per calculation. 
    * A lower number provides a slower result, but more practical if you 
    * have a large tile-map and don't want to block your thread while
    * finding a path.
    * 
    * @param {Number} iterations The number of searches to prefrom per calculate() call.
    **/
    this.setIterationsPerCalculation = function(iterations) {
        iterationsPerCalculation = iterations;
    };
    
    /**
    * Avoid a particular point on the grid, 
    * regardless of whether or not it is an acceptable tile.
    *
    * @param {Number} x The x value of the point to avoid.
    * @param {Number} y The y value of the point to avoid.
    **/
    this.avoidAdditionalPoint = function(x, y) {
        pointsToAvoid[x + "_" + y] = 1;
    };

    /**
    * Stop avoiding a particular point on the grid.
    *
    * @param {Number} x The x value of the point to stop avoiding.
    * @param {Number} y The y value of the point to stop avoiding.
    **/
    this.stopAvoidingAdditionalPoint = function(x, y) {
        delete pointsToAvoid[x + "_" + y];
    };

    /**
    * Enables corner cutting in diagonal movement.
    **/
    this.enableCornerCutting = function() {
        allowCornerCutting = true;
    };

    /**
    * Disables corner cutting in diagonal movement.
    **/
    this.disableCornerCutting = function() {
        allowCornerCutting = false;
    };

    /**
    * Stop avoiding all additional points on the grid.
    **/
    this.stopAvoidingAllAdditionalPoints = function() {
        pointsToAvoid = {};
    };

    /**
    * Find a path.
    * 
    * @param {Number} startX The X position of the starting point.
    * @param {Number} startY The Y position of the starting point.
    * @param {Number} endX The X position of the ending point.
    * @param {Number} endY The Y position of the ending point.
    * @param {Function} callback A function that is called when your path
    * is found, or no path is found.
    * 
    **/
    this.findPath = function(startX, startY, endX, endY, callback) {
        // Wraps the callback for sync vs async logic
        var callbackWrapper = function(result) {
            if (syncEnabled) {
                callback(result);
            } else {
                setTimeout(function() {
                    callback(result);
                });
            }
        }

        // No acceptable tiles were set
        if (acceptableTiles === undefined) {
            throw new Error("You can't set a path without first calling setAcceptableTiles() on EasyStar.");
        }
        // No grid was set
        if (collisionGrid === undefined) {
            throw new Error("You can't set a path without first calling setGrid() on EasyStar.");
        }

        // Start or endpoint outside of scope.
        if (startX < 0 || startY < 0 || endX < 0 || endY < 0 ||
        startX > collisionGrid[0].length-1 || startY > collisionGrid.length-1 || 
        endX > collisionGrid[0].length-1 || endY > collisionGrid.length-1) {
            throw new Error("Your start or end point is outside the scope of your grid.");
        }

        // Start and end are the same tile.
        if (startX===endX && startY===endY) {
            callbackWrapper([]);
            return;
        }

        // End point is not an acceptable tile.
        var endTile = collisionGrid[endY][endX];
        var isAcceptable = false;
        for (var i = 0; i < acceptableTiles.length; i++) {
            if (endTile === acceptableTiles[i]) {
                isAcceptable = true;
                break;
            }
        }

        if (isAcceptable === false) {
            callbackWrapper(null);
            return;
        }

        // Create the instance
        var instance = new Instance();
        instance.openList = new Heap(function(nodeA, nodeB) {
            return nodeA.bestGuessDistance() - nodeB.bestGuessDistance();
        });
        instance.isDoneCalculating = false;
        instance.nodeHash = {};
        instance.startX = startX;
        instance.startY = startY;
        instance.endX = endX;
        instance.endY = endY;
        instance.callback = callbackWrapper;

        instance.openList.push(coordinateToNode(instance, instance.startX, 
            instance.startY, null, STRAIGHT_COST));

        instances.push(instance);
    };

    /**
    * This method steps through the A* Algorithm in an attempt to
    * find your path(s). It will search 4-8 tiles (depending on diagonals) for every calculation.
    * You can change the number of calculations done in a call by using
    * easystar.setIteratonsPerCalculation().
    **/
    this.calculate = function() {
        if (instances.length === 0 || collisionGrid === undefined || acceptableTiles === undefined) {
            return;
        }
        for (iterationsSoFar = 0; iterationsSoFar < iterationsPerCalculation; iterationsSoFar++) {
            if (instances.length === 0) {
                return;
            }

            if (syncEnabled) {
                // If this is a sync instance, we want to make sure that it calculates synchronously. 
                iterationsSoFar = 0;
            }

            // Couldn't find a path.
            if (instances[0].openList.size() === 0) {
                var ic = instances[0];
                ic.callback(null);
                instances.shift();
                continue;
            }

            var searchNode = instances[0].openList.pop();

            // Handles the case where we have found the destination
            if (instances[0].endX === searchNode.x && instances[0].endY === searchNode.y) {
                instances[0].isDoneCalculating = true;
                var path = [];
                path.push({x: searchNode.x, y: searchNode.y});
                var parent = searchNode.parent;
                while (parent!=null) {
                    path.push({x: parent.x, y:parent.y});
                    parent = parent.parent;
                }
                path.reverse();
                var ic = instances[0];
                var ip = path;
                ic.callback(ip);
                return
            }

            var tilesToSearch = [];
            searchNode.list = CLOSED_LIST;

            if (searchNode.y > 0) {
                tilesToSearch.push({ instance: instances[0], searchNode: searchNode, 
                    x: 0, y: -1, cost: STRAIGHT_COST * getTileCost(searchNode.x, searchNode.y-1)});
            }
            if (searchNode.x < collisionGrid[0].length-1) {
                tilesToSearch.push({ instance: instances[0], searchNode: searchNode, 
                    x: 1, y: 0, cost: STRAIGHT_COST * getTileCost(searchNode.x+1, searchNode.y)});
            }
            if (searchNode.y < collisionGrid.length-1) {
                tilesToSearch.push({ instance: instances[0], searchNode: searchNode, 
                    x: 0, y: 1, cost: STRAIGHT_COST * getTileCost(searchNode.x, searchNode.y+1)});
            }
            if (searchNode.x > 0) {
                tilesToSearch.push({ instance: instances[0], searchNode: searchNode, 
                    x: -1, y: 0, cost: STRAIGHT_COST * getTileCost(searchNode.x-1, searchNode.y)});
            }
            if (diagonalsEnabled) {
                if (searchNode.x > 0 && searchNode.y > 0) {

                    if (allowCornerCutting ||
                        (isTileWalkable(collisionGrid, acceptableTiles, searchNode.x, searchNode.y-1) &&
                        isTileWalkable(collisionGrid, acceptableTiles, searchNode.x-1, searchNode.y))) {
                        
                        tilesToSearch.push({ instance: instances[0], searchNode: searchNode, 
                            x: -1, y: -1, cost: DIAGONAL_COST * getTileCost(searchNode.x-1, searchNode.y-1)});
                    }
                }
                if (searchNode.x < collisionGrid[0].length-1 && searchNode.y < collisionGrid.length-1) {

                    if (allowCornerCutting ||
                        (isTileWalkable(collisionGrid, acceptableTiles, searchNode.x, searchNode.y+1) &&
                        isTileWalkable(collisionGrid, acceptableTiles, searchNode.x+1, searchNode.y))) {
                        
                        tilesToSearch.push({ instance: instances[0], searchNode: searchNode, 
                            x: 1, y: 1, cost: DIAGONAL_COST * getTileCost(searchNode.x+1, searchNode.y+1)});
                    }
                }
                if (searchNode.x < collisionGrid[0].length-1 && searchNode.y > 0) {

                    if (allowCornerCutting ||
                        (isTileWalkable(collisionGrid, acceptableTiles, searchNode.x, searchNode.y-1) &&
                        isTileWalkable(collisionGrid, acceptableTiles, searchNode.x+1, searchNode.y))) {


                        tilesToSearch.push({ instance: instances[0], searchNode: searchNode, 
                            x: 1, y: -1, cost: DIAGONAL_COST * getTileCost(searchNode.x+1, searchNode.y-1)});
                    }
                }
                if (searchNode.x > 0 && searchNode.y < collisionGrid.length-1) {

                    if (allowCornerCutting ||
                        (isTileWalkable(collisionGrid, acceptableTiles, searchNode.x, searchNode.y+1) &&
                        isTileWalkable(collisionGrid, acceptableTiles, searchNode.x-1, searchNode.y))) {


                        tilesToSearch.push({ instance: instances[0], searchNode: searchNode, 
                            x: -1, y: 1, cost: DIAGONAL_COST * getTileCost(searchNode.x-1, searchNode.y+1)});
                    }
                }
            }

            var isDoneCalculating = false;

            // Search all of the surrounding nodes
            for (var i = 0; i < tilesToSearch.length; i++) {
                checkAdjacentNode(tilesToSearch[i].instance, tilesToSearch[i].searchNode, 
                    tilesToSearch[i].x, tilesToSearch[i].y, tilesToSearch[i].cost);
                if (tilesToSearch[i].instance.isDoneCalculating === true) {
                    isDoneCalculating = true;
                    break;
                }
            }

            if (isDoneCalculating) {
                instances.shift();
                continue;
            }

        }
    };

    // Private methods follow
    var checkAdjacentNode = function(instance, searchNode, x, y, cost) {
        var adjacentCoordinateX = searchNode.x+x;
        var adjacentCoordinateY = searchNode.y+y;

        if (pointsToAvoid[adjacentCoordinateX + "_" + adjacentCoordinateY] === undefined &&
            isTileWalkable(collisionGrid, acceptableTiles, adjacentCoordinateX, adjacentCoordinateY)) {
            var node = coordinateToNode(instance, adjacentCoordinateX, 
                adjacentCoordinateY, searchNode, cost);

            if (node.list === undefined) {
                node.list = OPEN_LIST;
                instance.openList.push(node);
            } else if (searchNode.costSoFar + cost < node.costSoFar) {
                node.costSoFar = searchNode.costSoFar + cost;
                node.parent = searchNode;
                instance.openList.updateItem(node);
            }
        }
    };

    // Helpers
    var isTileWalkable = function(collisionGrid, acceptableTiles, x, y) {
        for (var i = 0; i < acceptableTiles.length; i++) {
            if (collisionGrid[y][x] === acceptableTiles[i]) {
                return true;
            }
        }

        return false;
    };

    var getTileCost = function(x, y) {
        return pointsToCost[x + '_' + y] || costMap[collisionGrid[y][x]]
    };

    var coordinateToNode = function(instance, x, y, parent, cost) {
        if (instance.nodeHash[x + "_" + y]!==undefined) {
            return instance.nodeHash[x + "_" + y];
        }
        var simpleDistanceToTarget = getDistance(x, y, instance.endX, instance.endY);
        if (parent!==null) {
            var costSoFar = parent.costSoFar + cost;
        } else {
            costSoFar = 0;
        }
        var node = new Node(parent,x,y,costSoFar,simpleDistanceToTarget);
        instance.nodeHash[x + "_" + y] = node;
        return node;
    };

    var getDistance = function(x1,y1,x2,y2) {
        if (diagonalsEnabled) {
            // Octile distance
            var dx = Math.abs(x1 - x2);
            var dy = Math.abs(y1 - y2);
            if (dx < dy) {
                return DIAGONAL_COST * dx + dy;
            } else {
                return DIAGONAL_COST * dy + dx;
            }
        } else {
            // Manhattan distance
            var dx = Math.abs(x1 - x2);
            var dy = Math.abs(y1 - y2);
            return (dx + dy);
        }
    };
}
},{"./instance":3,"./node":4,"heap":6}],3:[function(require,module,exports){
/**
 * Represents a single instance of EasyStar.
 * A path that is in the queue to eventually be found.
 */
module.exports = function() {
    this.isDoneCalculating = true;
    this.pointsToAvoid = {};
    this.startX;
    this.callback;
    this.startY;
    this.endX;
    this.endY;
    this.nodeHash = {};
    this.openList;
};
},{}],4:[function(require,module,exports){
/**
* A simple Node that represents a single tile on the grid.
* @param {Object} parent The parent node.
* @param {Number} x The x position on the grid.
* @param {Number} y The y position on the grid.
* @param {Number} costSoFar How far this node is in moves*cost from the start.
* @param {Number} simpleDistanceToTarget Manhatten distance to the end point.
**/
module.exports = function(parent, x, y, costSoFar, simpleDistanceToTarget) {
    this.parent = parent;
    this.x = x;
    this.y = y;
    this.costSoFar = costSoFar;
    this.simpleDistanceToTarget = simpleDistanceToTarget;

    /**
    * @return {Number} Best guess distance of a cost using this node.
    **/
    this.bestGuessDistance = function() {
        return this.costSoFar + this.simpleDistanceToTarget;
    }
};
},{}],5:[function(require,module,exports){
/*
 * A speed-improved simplex noise algorithm for 2D, 3D and 4D in JavaScript.
 *
 * Based on example code by Stefan Gustavson (stegu@itn.liu.se).
 * Optimisations by Peter Eastman (peastman@drizzle.stanford.edu).
 * Better rank ordering method by Stefan Gustavson in 2012.
 *
 * This code was placed in the public domain by its original author,
 * Stefan Gustavson. You may use it as you see fit, but
 * attribution is appreciated.
 */

// Data ------------------------------------------------------------------------

var G2 = (3.0 - Math.sqrt(3.0)) / 6.0
var G3 = 1.0 / 6.0
var G4 = (5.0 - Math.sqrt(5.0)) / 20.0

var GRAD3 = [
  [1, 1, 0], [-1, 1, 0], [1, -1, 0], [-1, -1, 0],
  [1, 0, 1], [-1, 0, 1], [1, 0, -1], [-1, 0, -1],
  [0, 1, 1], [0, -1, -1], [0, 1, -1], [0, -1, -1]
]

var GRAD4 = [
  [0, 1, 1, 1], [0, 1, 1, -1], [0, 1, -1, 1], [0, 1, -1, -1],
  [0, -1, 1, 1], [0, -1, 1, -1], [0, -1, -1, 1], [0, -1, -1, -1],
  [1, 0, 1, 1], [1, 0, 1, -1], [1, 0, -1, 1], [1, 0, -1, -1],
  [-1, 0, 1, 1], [-1, 0, 1, -1], [-1, 0, -1, 1], [-1, 0, -1, -1],
  [1, 1, 0, 1], [1, 1, 0, -1], [1, -1, 0, 1], [1, -1, 0, -1],
  [-1, 1, 0, 1], [-1, 1, 0, -1], [-1, -1, 0, 1], [-1, -1, 0, -1],
  [1, 1, 1, 0], [1, 1, -1, 0], [1, -1, 1, 0], [1, -1, -1, 0],
  [-1, 1, 1, 0], [-1, 1, -1, 0], [-1, -1, 1, 0], [-1, -1, -1, 0]
]

// Exports ---------------------------------------------------------------------

if (typeof module !== 'undefined') module.exports = FastSimplexNoise

// Functions -------------------------------------------------------------------

function FastSimplexNoise (options) {
  if (!options) options = {}

  this.amplitude = options.amplitude || 1.0
  this.frequency = options.frequency || 1.0
  this.octaves = parseInt(options.octaves || 1)
  this.persistence = options.persistence || 0.5
  this.random = options.random || Math.random

  if (typeof options.min === 'number' && typeof options.max === 'number') {
    if (options.min >= options.max) {
      console.error('options.min must be less than options.max')
    } else {
      var min = parseFloat(options.min)
      var max = parseFloat(options.max)
      var range = max - min
      this.scale = function (value) {
        return min + ((value + 1) / 2) * range
      }
    }
  } else {
    this.scale = function (value) {
      return value
    }
  }

  var i
  var p = new Uint8Array(256)
  for (i = 0; i < 256; i++) {
    p[i] = i
  }

  var n, q
  for (i = 255; i > 0; i--) {
    n = Math.floor((i + 1) * this.random())
    q = p[i]
    p[i] = p[n]
    p[n] = q
  }

  // To remove the need for index wrapping, double the permutation table length
  this.perm = new Uint8Array(512)
  this.permMod12 = new Uint8Array(512)
  for (i = 0; i < 512; i++) {
    this.perm[i] = p[i & 255]
    this.permMod12[i] = this.perm[i] % 12
  }
}

FastSimplexNoise.prototype.cylindrical2D = function (c, x, y) {
  var nx = x / c
  var r = c / (2 * Math.PI)
  var rdx = nx * 2 * Math.PI
  var a = r * Math.sin(rdx)
  var b = r * Math.cos(rdx)

  return this.in3D(a, b, y)
}

FastSimplexNoise.prototype.cylindrical3D = function (c, x, y, z) {
  var nx = x / c
  var r = c / (2 * Math.PI)
  var rdx = nx * 2 * Math.PI
  var a = r * Math.sin(rdx)
  var b = r * Math.cos(rdx)

  return this.in4D(a, b, y, z)
}

FastSimplexNoise.prototype.in2D = function (x, y) {
  var amplitude = this.amplitude
  var frequency = this.frequency
  var maxAmplitude = 0
  var noise = 0
  var persistence = this.persistence

  for (var i = 0; i < this.octaves; i++) {
    noise += this.raw2D(x * frequency, y * frequency) * amplitude
    maxAmplitude += amplitude
    amplitude *= persistence
    frequency *= 2
  }

  var value = noise / maxAmplitude
  return this.scale(value)
}

FastSimplexNoise.prototype.in3D = function (x, y, z) {
  var amplitude = this.amplitude
  var frequency = this.frequency
  var maxAmplitude = 0
  var noise = 0
  var persistence = this.persistence

  for (var i = 0; i < this.octaves; i++) {
    noise += this.raw3D(x * frequency, y * frequency, z * frequency) * amplitude
    maxAmplitude += amplitude
    amplitude *= persistence
    frequency *= 2
  }

  var value = noise / maxAmplitude
  return this.scale(value)
}

FastSimplexNoise.prototype.in4D = function (x, y, z, w) {
  var amplitude = this.amplitude
  var frequency = this.frequency
  var maxAmplitude = 0
  var noise = 0
  var persistence = this.persistence

  for (var i = 0; i < this.octaves; i++) {
    noise += this.raw4D(x * frequency, y * frequency, z * frequency, w * frequency) * amplitude
    maxAmplitude += amplitude
    amplitude *= persistence
    frequency *= 2
  }

  var value = noise / maxAmplitude
  return this.scale(value)
}

FastSimplexNoise.prototype.raw2D = function (x, y) {
  var perm = this.perm
  var permMod12 = this.permMod12

  var n0, n1, n2 // Noise contributions from the three corners

  // Skew the input space to determine which simplex cell we're in
  var s = (x + y) * 0.5 * (Math.sqrt(3.0) - 1.0) // Hairy factor for 2D
  var i = Math.floor(x + s)
  var j = Math.floor(y + s)
  var t = (i + j) * G2
  var X0 = i - t // Unskew the cell origin back to (x,y) space
  var Y0 = j - t
  var x0 = x - X0 // The x,y distances from the cell origin
  var y0 = y - Y0

  // For the 2D case, the simplex shape is an equilateral triangle.
  // Determine which simplex we are in.
  var i1, j1 // Offsets for second (middle) corner of simplex in (i,j) coords
  if (x0 > y0) { // Lower triangle, XY order: (0,0)->(1,0)->(1,1)
    i1 = 1
    j1 = 0
  } else { // Upper triangle, YX order: (0,0)->(0,1)->(1,1)
    i1 = 0
    j1 = 1
  }

  // A step of (1,0) in (i,j) means a step of (1-c,-c) in (x,y), and
  // a step of (0,1) in (i,j) means a step of (-c,1-c) in (x,y), where
  // c = (3 - sqrt(3)) / 6

  var x1 = x0 - i1 + G2 // Offsets for middle corner in (x,y) unskewed coords
  var y1 = y0 - j1 + G2
  var x2 = x0 - 1.0 + 2.0 * G2 // Offsets for last corner in (x,y) unskewed coords
  var y2 = y0 - 1.0 + 2.0 * G2

  // Work out the hashed gradient indices of the three simplex corners
  var ii = i & 255
  var jj = j & 255
  var gi0 = permMod12[ii + perm[jj]]
  var gi1 = permMod12[ii + i1 + perm[jj + j1]]
  var gi2 = permMod12[ii + 1 + perm[jj + 1]]

  // Calculate the contribution from the three corners
  var t0 = 0.5 - x0 * x0 - y0 * y0
  if (t0 < 0) {
    n0 = 0.0
  } else {
    t0 *= t0
    // (x,y) of 3D gradient used for 2D gradient
    n0 = t0 * t0 * dot2D(GRAD3[gi0], x0, y0)
  }
  var t1 = 0.5 - x1 * x1 - y1 * y1
  if (t1 < 0) {
    n1 = 0.0
  } else {
    t1 *= t1
    n1 = t1 * t1 * dot2D(GRAD3[gi1], x1, y1)
  }
  var t2 = 0.5 - x2 * x2 - y2 * y2
  if (t2 < 0) {
    n2 = 0.0
  } else {
    t2 *= t2
    n2 = t2 * t2 * dot2D(GRAD3[gi2], x2, y2)
  }

  // Add contributions from each corner to get the final noise value.
  // The result is scaled to return values in the interval [-1, 1]
  return 70.14805770654148 * (n0 + n1 + n2)
}

FastSimplexNoise.prototype.raw3D = function (x, y, z) {
  var perm = this.perm
  var permMod12 = this.permMod12

  var n0, n1, n2, n3 // Noise contributions from the four corners

  // Skew the input space to determine which simplex cell we're in
  var s = (x + y + z) / 3.0 // Very nice and simple skew factor for 3D
  var i = Math.floor(x + s)
  var j = Math.floor(y + s)
  var k = Math.floor(z + s)
  var t = (i + j + k) * G3
  var X0 = i - t // Unskew the cell origin back to (x,y,z) space
  var Y0 = j - t
  var Z0 = k - t
  var x0 = x - X0 // The x,y,z distances from the cell origin
  var y0 = y - Y0
  var z0 = z - Z0

  // For the 3D case, the simplex shape is a slightly irregular tetrahedron.
  // Determine which simplex we are in.
  var i1, j1, k1 // Offsets for second corner of simplex in (i,j,k) coords
  var i2, j2, k2 // Offsets for third corner of simplex in (i,j,k) coords
  if (x0 >= y0) {
    if (y0 >= z0) { // X Y Z order
      i1 = 1; j1 = 0; k1 = 0; i2 = 1; j2 = 1; k2 = 0
    } else if (x0 >= z0) { // X Z Y order
      i1 = 1; j1 = 0; k1 = 0; i2 = 1; j2 = 0; k2 = 1
    } else { // Z X Y order
      i1 = 0; j1 = 0; k1 = 1; i2 = 1; j2 = 0; k2 = 1
    }
  } else { // x0 < y0
    if (y0 < z0) { // Z Y X order
      i1 = 0; j1 = 0; k1 = 1; i2 = 0; j2 = 1; k2 = 1
    } else if (x0 < z0) { // Y Z X order
      i1 = 0; j1 = 1; k1 = 0; i2 = 0; j2 = 1; k2 = 1
    } else { // Y X Z order
      i1 = 0; j1 = 1; k1 = 0; i2 = 1; j2 = 1; k2 = 0
    }
  }

  // A step of (1,0,0) in (i,j,k) means a step of (1-c,-c,-c) in (x,y,z),
  // a step of (0,1,0) in (i,j,k) means a step of (-c,1-c,-c) in (x,y,z), and
  // a step of (0,0,1) in (i,j,k) means a step of (-c,-c,1-c) in (x,y,z), where
  // c = 1/6.
  var x1 = x0 - i1 + G3 // Offsets for second corner in (x,y,z) coords
  var y1 = y0 - j1 + G3
  var z1 = z0 - k1 + G3
  var x2 = x0 - i2 + 2.0 * G3 // Offsets for third corner in (x,y,z) coords
  var y2 = y0 - j2 + 2.0 * G3
  var z2 = z0 - k2 + 2.0 * G3
  var x3 = x0 - 1.0 + 3.0 * G3 // Offsets for last corner in (x,y,z) coords
  var y3 = y0 - 1.0 + 3.0 * G3
  var z3 = z0 - 1.0 + 3.0 * G3

  // Work out the hashed gradient indices of the four simplex corners
  var ii = i & 255
  var jj = j & 255
  var kk = k & 255
  var gi0 = permMod12[ii + perm[jj + perm[kk]]]
  var gi1 = permMod12[ii + i1 + perm[jj + j1 + perm[kk + k1]]]
  var gi2 = permMod12[ii + i2 + perm[jj + j2 + perm[kk + k2]]]
  var gi3 = permMod12[ii + 1 + perm[jj + 1 + perm[kk + 1]]]

  // Calculate the contribution from the four corners
  var t0 = 0.5 - x0 * x0 - y0 * y0 - z0 * z0
  if (t0 < 0) {
    n0 = 0.0
  } else {
    t0 *= t0
    n0 = t0 * t0 * dot3D(GRAD3[gi0], x0, y0, z0)
  }
  var t1 = 0.5 - x1 * x1 - y1 * y1 - z1 * z1
  if (t1 < 0) {
    n1 = 0.0
  } else {
    t1 *= t1
    n1 = t1 * t1 * dot3D(GRAD3[gi1], x1, y1, z1)
  }
  var t2 = 0.5 - x2 * x2 - y2 * y2 - z2 * z2
  if (t2 < 0) {
    n2 = 0.0
  } else {
    t2 *= t2
    n2 = t2 * t2 * dot3D(GRAD3[gi2], x2, y2, z2)
  }
  var t3 = 0.5 - x3 * x3 - y3 * y3 - z3 * z3
  if (t3 < 0) {
    n3 = 0.0
  } else {
    t3 *= t3
    n3 = t3 * t3 * dot3D(GRAD3[gi3], x3, y3, z3)
  }

  // Add contributions from each corner to get the final noise value.
  // The result is scaled to stay just inside [-1,1]
  return 94.68493150681972 * (n0 + n1 + n2 + n3)
}

FastSimplexNoise.prototype.raw4D = function (x, y, z, w) {
  var perm = this.perm

  var n0, n1, n2, n3, n4 // Noise contributions from the five corners

  // Skew the (x,y,z,w) space to determine which cell of 24 simplices we're in
  var s = (x + y + z + w) * (Math.sqrt(5.0) - 1.0) / 4.0 // Factor for 4D skewing
  var i = Math.floor(x + s)
  var j = Math.floor(y + s)
  var k = Math.floor(z + s)
  var l = Math.floor(w + s)
  var t = (i + j + k + l) * G4 // Factor for 4D unskewing
  var X0 = i - t // Unskew the cell origin back to (x,y,z,w) space
  var Y0 = j - t
  var Z0 = k - t
  var W0 = l - t
  var x0 = x - X0  // The x,y,z,w distances from the cell origin
  var y0 = y - Y0
  var z0 = z - Z0
  var w0 = w - W0

  // For the 4D case, the simplex is a 4D shape I won't even try to describe.
  // To find out which of the 24 possible simplices we're in, we need to
  // determine the magnitude ordering of x0, y0, z0 and w0.
  // Six pair-wise comparisons are performed between each possible pair
  // of the four coordinates, and the results are used to rank the numbers.
  var rankx = 0
  var ranky = 0
  var rankz = 0
  var rankw = 0
  if (x0 > y0) {
    rankx++
  } else {
    ranky++
  }
  if (x0 > z0) {
    rankx++
  } else {
    rankz++
  }
  if (x0 > w0) {
    rankx++
  } else {
    rankw++
  }
  if (y0 > z0) {
    ranky++
  } else {
    rankz++
  }
  if (y0 > w0) {
    ranky++
  } else {
    rankw++
  }
  if (z0 > w0) {
    rankz++
  } else {
    rankw++
  }
  var i1, j1, k1, l1 // The integer offsets for the second simplex corner
  var i2, j2, k2, l2 // The integer offsets for the third simplex corner
  var i3, j3, k3, l3 // The integer offsets for the fourth simplex corner

  // simplex[c] is a 4-vector with the numbers 0, 1, 2 and 3 in some order.
  // Many values of c will never occur, since e.g. x>y>z>w makes x<z, y<w and x<w
  // impossible. Only the 24 indices which have non-zero entries make any sense.
  // We use a thresholding to set the coordinates in turn from the largest magnitude.
  // Rank 3 denotes the largest coordinate.
  i1 = rankx >= 3 ? 1 : 0
  j1 = ranky >= 3 ? 1 : 0
  k1 = rankz >= 3 ? 1 : 0
  l1 = rankw >= 3 ? 1 : 0
  // Rank 2 denotes the second largest coordinate.
  i2 = rankx >= 2 ? 1 : 0
  j2 = ranky >= 2 ? 1 : 0
  k2 = rankz >= 2 ? 1 : 0
  l2 = rankw >= 2 ? 1 : 0
  // Rank 1 denotes the second smallest coordinate.
  i3 = rankx >= 1 ? 1 : 0
  j3 = ranky >= 1 ? 1 : 0
  k3 = rankz >= 1 ? 1 : 0
  l3 = rankw >= 1 ? 1 : 0

  // The fifth corner has all coordinate offsets = 1, so no need to compute that.
  var x1 = x0 - i1 + G4 // Offsets for second corner in (x,y,z,w) coords
  var y1 = y0 - j1 + G4
  var z1 = z0 - k1 + G4
  var w1 = w0 - l1 + G4
  var x2 = x0 - i2 + 2.0 * G4 // Offsets for third corner in (x,y,z,w) coords
  var y2 = y0 - j2 + 2.0 * G4
  var z2 = z0 - k2 + 2.0 * G4
  var w2 = w0 - l2 + 2.0 * G4
  var x3 = x0 - i3 + 3.0 * G4 // Offsets for fourth corner in (x,y,z,w) coords
  var y3 = y0 - j3 + 3.0 * G4
  var z3 = z0 - k3 + 3.0 * G4
  var w3 = w0 - l3 + 3.0 * G4
  var x4 = x0 - 1.0 + 4.0 * G4 // Offsets for last corner in (x,y,z,w) coords
  var y4 = y0 - 1.0 + 4.0 * G4
  var z4 = z0 - 1.0 + 4.0 * G4
  var w4 = w0 - 1.0 + 4.0 * G4

  // Work out the hashed gradient indices of the five simplex corners
  var ii = i & 255
  var jj = j & 255
  var kk = k & 255
  var ll = l & 255
  var gi0 = perm[ii + perm[jj + perm[kk + perm[ll]]]] % 32
  var gi1 = perm[ii + i1 + perm[jj + j1 + perm[kk + k1 + perm[ll + l1]]]] % 32
  var gi2 = perm[ii + i2 + perm[jj + j2 + perm[kk + k2 + perm[ll + l2]]]] % 32
  var gi3 = perm[ii + i3 + perm[jj + j3 + perm[kk + k3 + perm[ll + l3]]]] % 32
  var gi4 = perm[ii + 1 + perm[jj + 1 + perm[kk + 1 + perm[ll + 1]]]] % 32

  // Calculate the contribution from the five corners
  var t0 = 0.5 - x0 * x0 - y0 * y0 - z0 * z0 - w0 * w0
  if (t0 < 0) {
    n0 = 0.0
  } else {
    t0 *= t0
    n0 = t0 * t0 * dot4D(GRAD4[gi0], x0, y0, z0, w0)
  }
  var t1 = 0.5 - x1 * x1 - y1 * y1 - z1 * z1 - w1 * w1
  if (t1 < 0) {
    n1 = 0.0
  } else {
    t1 *= t1
    n1 = t1 * t1 * dot4D(GRAD4[gi1], x1, y1, z1, w1)
  }
  var t2 = 0.5 - x2 * x2 - y2 * y2 - z2 * z2 - w2 * w2
  if (t2 < 0) {
    n2 = 0.0
  } else {
    t2 *= t2
    n2 = t2 * t2 * dot4D(GRAD4[gi2], x2, y2, z2, w2)
  }
  var t3 = 0.5 - x3 * x3 - y3 * y3 - z3 * z3 - w3 * w3
  if (t3 < 0) {
    n3 = 0.0
  } else {
    t3 *= t3
    n3 = t3 * t3 * dot4D(GRAD4[gi3], x3, y3, z3, w3)
  }
  var t4 = 0.5 - x4 * x4 - y4 * y4 - z4 * z4 - w4 * w4
  if (t4 < 0) {
    n4 = 0.0
  } else {
    t4 *= t4
    n4 = t4 * t4 * dot4D(GRAD4[gi4], x4, y4, z4, w4)
  }

  // Sum up and scale the result to cover the range [-1,1]
  return 72.37857097679466 * (n0 + n1 + n2 + n3 + n4)
}

FastSimplexNoise.prototype.spherical2D = function (c, x, y) {
  var nx = x / c
  var ny = y / c
  var rdx = nx * 2 * Math.PI
  var rdy = ny * Math.PI
  var sinY = Math.sin(rdy + Math.PI)
  var sinRds = 2 * Math.PI
  var a = sinRds * Math.sin(rdx) * sinY
  var b = sinRds * Math.cos(rdx) * sinY
  var d = sinRds * Math.cos(rdy)

  return this.in3D(a, b, d)
}

FastSimplexNoise.prototype.spherical3D = function (c, x, y, z) {
  var nx = x / c
  var ny = y / c
  var rdx = nx * 2 * Math.PI
  var rdy = ny * Math.PI
  var sinY = Math.sin(rdy + Math.PI)
  var sinRds = 2 * Math.PI
  var a = sinRds * Math.sin(rdx) * sinY
  var b = sinRds * Math.cos(rdx) * sinY
  var d = sinRds * Math.cos(rdy)

  return this.in4D(a, b, d, z)
}

function dot2D (g, x, y) {
  return g[0] * x + g[1] * y
}

function dot3D (g, x, y, z) {
  return g[0] * x + g[1] * y + g[2] * z
}

function dot4D (g, x, y, z, w) {
  return g[0] * x + g[1] * y + g[2] * z + g[3] * w
}

},{}],6:[function(require,module,exports){
module.exports = require('./lib/heap');

},{"./lib/heap":7}],7:[function(require,module,exports){
// Generated by CoffeeScript 1.8.0
(function() {
  var Heap, defaultCmp, floor, heapify, heappop, heappush, heappushpop, heapreplace, insort, min, nlargest, nsmallest, updateItem, _siftdown, _siftup;

  floor = Math.floor, min = Math.min;


  /*
  Default comparison function to be used
   */

  defaultCmp = function(x, y) {
    if (x < y) {
      return -1;
    }
    if (x > y) {
      return 1;
    }
    return 0;
  };


  /*
  Insert item x in list a, and keep it sorted assuming a is sorted.
  
  If x is already in a, insert it to the right of the rightmost x.
  
  Optional args lo (default 0) and hi (default a.length) bound the slice
  of a to be searched.
   */

  insort = function(a, x, lo, hi, cmp) {
    var mid;
    if (lo == null) {
      lo = 0;
    }
    if (cmp == null) {
      cmp = defaultCmp;
    }
    if (lo < 0) {
      throw new Error('lo must be non-negative');
    }
    if (hi == null) {
      hi = a.length;
    }
    while (lo < hi) {
      mid = floor((lo + hi) / 2);
      if (cmp(x, a[mid]) < 0) {
        hi = mid;
      } else {
        lo = mid + 1;
      }
    }
    return ([].splice.apply(a, [lo, lo - lo].concat(x)), x);
  };


  /*
  Push item onto heap, maintaining the heap invariant.
   */

  heappush = function(array, item, cmp) {
    if (cmp == null) {
      cmp = defaultCmp;
    }
    array.push(item);
    return _siftdown(array, 0, array.length - 1, cmp);
  };


  /*
  Pop the smallest item off the heap, maintaining the heap invariant.
   */

  heappop = function(array, cmp) {
    var lastelt, returnitem;
    if (cmp == null) {
      cmp = defaultCmp;
    }
    lastelt = array.pop();
    if (array.length) {
      returnitem = array[0];
      array[0] = lastelt;
      _siftup(array, 0, cmp);
    } else {
      returnitem = lastelt;
    }
    return returnitem;
  };


  /*
  Pop and return the current smallest value, and add the new item.
  
  This is more efficient than heappop() followed by heappush(), and can be
  more appropriate when using a fixed size heap. Note that the value
  returned may be larger than item! That constrains reasonable use of
  this routine unless written as part of a conditional replacement:
      if item > array[0]
        item = heapreplace(array, item)
   */

  heapreplace = function(array, item, cmp) {
    var returnitem;
    if (cmp == null) {
      cmp = defaultCmp;
    }
    returnitem = array[0];
    array[0] = item;
    _siftup(array, 0, cmp);
    return returnitem;
  };


  /*
  Fast version of a heappush followed by a heappop.
   */

  heappushpop = function(array, item, cmp) {
    var _ref;
    if (cmp == null) {
      cmp = defaultCmp;
    }
    if (array.length && cmp(array[0], item) < 0) {
      _ref = [array[0], item], item = _ref[0], array[0] = _ref[1];
      _siftup(array, 0, cmp);
    }
    return item;
  };


  /*
  Transform list into a heap, in-place, in O(array.length) time.
   */

  heapify = function(array, cmp) {
    var i, _i, _j, _len, _ref, _ref1, _results, _results1;
    if (cmp == null) {
      cmp = defaultCmp;
    }
    _ref1 = (function() {
      _results1 = [];
      for (var _j = 0, _ref = floor(array.length / 2); 0 <= _ref ? _j < _ref : _j > _ref; 0 <= _ref ? _j++ : _j--){ _results1.push(_j); }
      return _results1;
    }).apply(this).reverse();
    _results = [];
    for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
      i = _ref1[_i];
      _results.push(_siftup(array, i, cmp));
    }
    return _results;
  };


  /*
  Update the position of the given item in the heap.
  This function should be called every time the item is being modified.
   */

  updateItem = function(array, item, cmp) {
    var pos;
    if (cmp == null) {
      cmp = defaultCmp;
    }
    pos = array.indexOf(item);
    if (pos === -1) {
      return;
    }
    _siftdown(array, 0, pos, cmp);
    return _siftup(array, pos, cmp);
  };


  /*
  Find the n largest elements in a dataset.
   */

  nlargest = function(array, n, cmp) {
    var elem, result, _i, _len, _ref;
    if (cmp == null) {
      cmp = defaultCmp;
    }
    result = array.slice(0, n);
    if (!result.length) {
      return result;
    }
    heapify(result, cmp);
    _ref = array.slice(n);
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      elem = _ref[_i];
      heappushpop(result, elem, cmp);
    }
    return result.sort(cmp).reverse();
  };


  /*
  Find the n smallest elements in a dataset.
   */

  nsmallest = function(array, n, cmp) {
    var elem, i, los, result, _i, _j, _len, _ref, _ref1, _results;
    if (cmp == null) {
      cmp = defaultCmp;
    }
    if (n * 10 <= array.length) {
      result = array.slice(0, n).sort(cmp);
      if (!result.length) {
        return result;
      }
      los = result[result.length - 1];
      _ref = array.slice(n);
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        elem = _ref[_i];
        if (cmp(elem, los) < 0) {
          insort(result, elem, 0, null, cmp);
          result.pop();
          los = result[result.length - 1];
        }
      }
      return result;
    }
    heapify(array, cmp);
    _results = [];
    for (i = _j = 0, _ref1 = min(n, array.length); 0 <= _ref1 ? _j < _ref1 : _j > _ref1; i = 0 <= _ref1 ? ++_j : --_j) {
      _results.push(heappop(array, cmp));
    }
    return _results;
  };

  _siftdown = function(array, startpos, pos, cmp) {
    var newitem, parent, parentpos;
    if (cmp == null) {
      cmp = defaultCmp;
    }
    newitem = array[pos];
    while (pos > startpos) {
      parentpos = (pos - 1) >> 1;
      parent = array[parentpos];
      if (cmp(newitem, parent) < 0) {
        array[pos] = parent;
        pos = parentpos;
        continue;
      }
      break;
    }
    return array[pos] = newitem;
  };

  _siftup = function(array, pos, cmp) {
    var childpos, endpos, newitem, rightpos, startpos;
    if (cmp == null) {
      cmp = defaultCmp;
    }
    endpos = array.length;
    startpos = pos;
    newitem = array[pos];
    childpos = 2 * pos + 1;
    while (childpos < endpos) {
      rightpos = childpos + 1;
      if (rightpos < endpos && !(cmp(array[childpos], array[rightpos]) < 0)) {
        childpos = rightpos;
      }
      array[pos] = array[childpos];
      pos = childpos;
      childpos = 2 * pos + 1;
    }
    array[pos] = newitem;
    return _siftdown(array, startpos, pos, cmp);
  };

  Heap = (function() {
    Heap.push = heappush;

    Heap.pop = heappop;

    Heap.replace = heapreplace;

    Heap.pushpop = heappushpop;

    Heap.heapify = heapify;

    Heap.updateItem = updateItem;

    Heap.nlargest = nlargest;

    Heap.nsmallest = nsmallest;

    function Heap(cmp) {
      this.cmp = cmp != null ? cmp : defaultCmp;
      this.nodes = [];
    }

    Heap.prototype.push = function(x) {
      return heappush(this.nodes, x, this.cmp);
    };

    Heap.prototype.pop = function() {
      return heappop(this.nodes, this.cmp);
    };

    Heap.prototype.peek = function() {
      return this.nodes[0];
    };

    Heap.prototype.contains = function(x) {
      return this.nodes.indexOf(x) !== -1;
    };

    Heap.prototype.replace = function(x) {
      return heapreplace(this.nodes, x, this.cmp);
    };

    Heap.prototype.pushpop = function(x) {
      return heappushpop(this.nodes, x, this.cmp);
    };

    Heap.prototype.heapify = function() {
      return heapify(this.nodes, this.cmp);
    };

    Heap.prototype.updateItem = function(x) {
      return updateItem(this.nodes, x, this.cmp);
    };

    Heap.prototype.clear = function() {
      return this.nodes = [];
    };

    Heap.prototype.empty = function() {
      return this.nodes.length === 0;
    };

    Heap.prototype.size = function() {
      return this.nodes.length;
    };

    Heap.prototype.clone = function() {
      var heap;
      heap = new Heap();
      heap.nodes = this.nodes.slice(0);
      return heap;
    };

    Heap.prototype.toArray = function() {
      return this.nodes.slice(0);
    };

    Heap.prototype.insert = Heap.prototype.push;

    Heap.prototype.top = Heap.prototype.peek;

    Heap.prototype.front = Heap.prototype.peek;

    Heap.prototype.has = Heap.prototype.contains;

    Heap.prototype.copy = Heap.prototype.clone;

    return Heap;

  })();

  (function(root, factory) {
    if (typeof define === 'function' && define.amd) {
      return define([], factory);
    } else if (typeof exports === 'object') {
      return module.exports = factory();
    } else {
      return root.Heap = factory();
    }
  })(this, function() {
    return Heap;
  });

}).call(this);

},{}],8:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
var BLOCK_TYPE = {
  walkable: 0,
  solid: 1,
  mineable: 2,
  tmpwalkable: 3
};

exports.default = BLOCK_TYPE;

},{}],9:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  "clear": { name: "clear", tile: -1, walk: true },
  "empty": { name: "empty", tile: 0, walk: true },
  "tree": { name: "tree", tile: 257, mine: true, hardness: 10, yields: [{ name: "wood", amount: 1 }] },
  "coal_ore": { name: "coal_ore", tile: 258, mine: true, hardness: 20, yields: [{ name: "coal", amount: 1 }] },
  "stone_ore": { name: "stone_ore", tile: 259, mine: true, hardness: 50, yields: [{ name: "stone", amount: 1 }] },
  "water": { name: "water", tile: 2, mine: false },
  "sand": { name: "sand", tile: 1, mine: false, walk: true },

  getByTileId: function getByTileId(id) {
    for (var e in this) {
      if (this[e].tile && this[e].tile === id) {
        return this[e];
      }
    }
    return this.empty;
  }
};

},{}],10:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Controls = function () {
  function Controls(game) {
    var _this = this;

    _classCallCheck(this, Controls);

    this.isDown = false;
    this.justPressed = false;

    this.game = game;
    this.setActive();
    // "activePointer" seems to change on mobile
    setTimeout(function () {
      _this.setActive();
    }, 2000);
  }

  _createClass(Controls, [{
    key: "setActive",
    value: function setActive() {
      this.pointer = this.game.input.activePointer;
    }
  }, {
    key: "update",
    value: function update() {
      var pointer = this.game.input.activePointer;
      if (!pointer) {
        return;
      }
      if (pointer.isDown && !this.isDown) {
        this.isDown = true;
        this.justPressed = true;
      } else if (pointer.isDown) {
        this.justPressed = false;
      } else {
        this.isDown = false;
      }
    }
  }, {
    key: "x",
    get: function get() {
      return this.pointer.x;
    }
  }, {
    key: "y",
    get: function get() {
      return this.pointer.y;
    }
  }, {
    key: "worldX",
    get: function get() {
      return this.pointer.worldX;
    }
  }, {
    key: "worldY",
    get: function get() {
      return this.pointer.worldY;
    }
  }]);

  return Controls;
}();

exports.default = Controls;

},{}],11:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _World = require("./screens/World");

var _World2 = _interopRequireDefault(_World);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Phaser = window.Phaser;

var Game = function (_Phaser$Game) {
  _inherits(Game, _Phaser$Game);

  function Game() {
    _classCallCheck(this, Game);

    var _this = _possibleConstructorReturn(this, (Game.__proto__ || Object.getPrototypeOf(Game)).call(this, 374, 559, Phaser.AUTO, "bmax", null));

    _this.state.add("World", _World2.default, false);
    _this.state.start("World");
    return _this;
  }

  return Game;
}(Phaser.Game);

exports.default = Game;

},{"./screens/World":21}],12:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Items = require("./Items");

var _Items2 = _interopRequireDefault(_Items);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Phaser = window.Phaser;

var Slot = function (_Phaser$Group) {
  _inherits(Slot, _Phaser$Group);

  function Slot(game, idx) {
    _classCallCheck(this, Slot);

    var _this = _possibleConstructorReturn(this, (Slot.__proto__ || Object.getPrototypeOf(Slot)).call(this, game));

    _this.item = null;
    _this.amount = 0;

    _this.idx = idx;

    var icon = _this.create(0, 0, "icons");
    icon.fixedToCamera = true;
    icon.frame = _Items2.default.empty.icon;

    var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ .,!?'\":-$                0123456789";
    var amount = game.add.retroFont("bmaxFont9", 9, 9, chars, 13, 0, 0, 0, 0);
    _this.create(24, 24, amount).fixedToCamera = true;

    _this.ui = {
      icon: icon,
      amount: amount
    };

    return _this;
  }

  _createClass(Slot, [{
    key: "updateUI",
    value: function updateUI() {
      var item = this.item;
      var amount = this.amount;
      var ui = this.ui;

      ui.icon.frame = !item ? _Items2.default.empty.icon : _Items2.default[item].icon;
      ui.amount.text = (amount < 2 ? "" : amount) + "";
    }
  }, {
    key: "setItem",
    value: function setItem(item) {
      var amount = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;

      this.item = item;
      this.amount = amount;
      this.updateUI();
      return this;
    }
  }, {
    key: "addItem",
    value: function addItem() {
      var amount = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;

      this.amount += amount;
      if (this.amount <= 0) {
        this.item = null;
        this.amount = 0;
      }
      this.updateUI();
      return this;
    }
  }]);

  return Slot;
}(Phaser.Group);

var Inventory = function (_Phaser$Group2) {
  _inherits(Inventory, _Phaser$Group2);

  function Inventory(game, onItemSwitch) {
    _classCallCheck(this, Inventory);

    var _this2 = _possibleConstructorReturn(this, (Inventory.__proto__ || Object.getPrototypeOf(Inventory)).call(this, game));

    _this2.maxSlots = 12;
    _this2.slotsPerRow = 6;
    _this2.slotTileW = 48;
    _this2.slotTileH = 48;

    game.add.existing(_this2);

    _this2.onItemSwitch = onItemSwitch;

    var box = _this2.create(game.width / 2 - 144, game.height - 100, "inventory");
    box.fixedToCamera = true;
    box.inputEnabled = true;
    box.events.onInputDown.add(_this2.onClick, _this2);

    var selected = _this2.create(box.x, box.y, "inv-selection");
    selected.fixedToCamera = true;

    _this2.slots = Array.from(new Array(_this2.maxSlots), function (_, i) {
      var s = new Slot(game, i);
      s.x = box.x + i % _this2.slotsPerRow * _this2.slotTileW + 6;
      s.y = box.y + (i / _this2.slotsPerRow | 0) * _this2.slotTileH + 8;
      return s;
    }).map(function (s) {
      return _this2.add(s);
    });

    var pda = _this2.create(4, box.y + 6, "icons");
    pda.fixedToCamera = true;
    pda.frame = 22;

    _this2.ui = {
      box: box,
      selected: selected
    };

    _this2.selectItem(-1);

    return _this2;
  }

  _createClass(Inventory, [{
    key: "onClick",
    value: function onClick(box, click) {
      var x = (click.x - box.cameraOffset.x) / this.slotTileW | 0;
      var y = (click.y - box.cameraOffset.y) / this.slotTileH | 0;
      this.selectItem(y * this.slotsPerRow + x);
    }
  }, {
    key: "selectItem",
    value: function selectItem(idx, dontDeselect) {
      var deselect = this.selected === idx;
      if (dontDeselect && deselect) {
        return;
      }
      if (deselect || idx < 0 || idx > this.maxSlots) {
        this.selected = -1;
        this.ui.selected.visible = false;
        return;
      }
      this.selected = idx;
      this.ui.selected.visible = true;
      this.ui.selected.cameraOffset.x = this.ui.box.cameraOffset.x + idx % this.slotsPerRow * this.slotTileW - 4;
      this.ui.selected.cameraOffset.y = this.ui.box.cameraOffset.y + (idx / this.slotsPerRow | 0) * this.slotTileH;

      this.onItemSwitch(this.holding());
    }
  }, {
    key: "holding",
    value: function holding() {
      if (this.selected < 0 || !this.slots[this.selected].item) {
        return {
          item: "empty",
          amount: 0
        };
      }
      return this.slots[this.selected];
    }
  }, {
    key: "addItem",
    value: function addItem(item) {
      var amount = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;

      var firstMatch = this.slots.find(function (s) {
        return s.item === item;
      });
      var firstEmpty = this.slots.find(function (s) {
        return s.item === null;
      });

      var slot = null;
      if (firstMatch) {
        slot = firstMatch.addItem(amount);
      } else if (firstEmpty) {
        slot = firstEmpty.setItem(item, amount);
      } else {
        // No room!
      }
      return slot;
    }
  }, {
    key: "hasItem",
    value: function hasItem(item) {
      var amount = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;

      var match = this.slots.find(function (s) {
        return s.item === item;
      });
      return match && match.amount >= amount;
    }
  }, {
    key: "useItem",
    value: function useItem(item, amount) {
      var match = this.slots.find(function (s) {
        return s.item === item;
      });
      if (match && match.amount >= amount) {
        match.addItem(-amount);
        return true;
      }
      return false;
    }
  }]);

  return Inventory;
}(Phaser.Group);

exports.default = Inventory;

},{"./Items":13}],13:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  "empty": { name: "empty", carry: true, icon: 0 },
  "wood": { name: "wood", carry: true, icon: 1 },
  "coal": { name: "coal", carry: true, icon: 2 },
  "stone": { name: "stone", carry: true, icon: 3 },
  "wood_sword": { name: "wood_sword", carry: true, icon: 10, damage: 1 },
  "wood_pick": { name: "wood_pick", carry: true, icon: 11, efficiency: 5 },
  "wood_axe": { name: "wood_pick", carry: true, icon: 12 }
};

},{}],14:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Blocks = require("./Blocks");

var _Blocks2 = _interopRequireDefault(_Blocks);

var _BLOCK_TYPE = require("./BLOCK_TYPE");

var _BLOCK_TYPE2 = _interopRequireDefault(_BLOCK_TYPE);

var _easystarjs = require("easystarjs");

var _easystarjs2 = _interopRequireDefault(_easystarjs);

var _Player = require("./entities/Player");

var _Player2 = _interopRequireDefault(_Player);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Phaser = window.Phaser;
//import Items from "../Items";


var FastSimplexNoise = require("fast-simplex-noise");

var Map = function () {
  function Map(game) {
    _classCallCheck(this, Map);

    this.create(game);
  }

  _createClass(Map, [{
    key: "create",
    value: function create(game) {
      // Generate 2D noise in a 1024x768 grid, scaled to [0, 255]
      var noiseBase = new FastSimplexNoise({
        frequency: 0.1,
        max: 1,
        min: 0,
        octaves: 4
      });

      var noiseTrees = new FastSimplexNoise({
        frequency: 0.07,
        max: 1,
        min: 0,
        octaves: 4
      });

      var noiseOres = new FastSimplexNoise({
        frequency: 0.01,
        max: 1,
        min: 0,
        octaves: 8
      });

      var grid = [];
      var gridMid = [];
      var h = 55;
      var w = 55;

      var min = 1,
          max = 0;
      for (var x = 0; x < h; x++) {
        grid[x] = [];
        gridMid[x] = [];
        for (var y = 0; y < w; y++) {
          grid[x][y] = noiseBase.in2D(x, y) > 0.62 ? 2 : 1;
          gridMid[x][y] = 0;

          if (grid[x][y] !== 1) {
            continue;
          }
          var v = noiseTrees.in2D(x, y);
          min = Math.min(min, v);
          max = Math.max(max, v);
          if (v > 0.5 && v < 0.52) {
            gridMid[x][y] = 257;
          }

          var o = noiseOres.in2D(x, y);
          if (o > 0.5 && o < 0.504) {
            gridMid[x][y] = 258;
          } else if (o > 0.6 && o < 0.601) {
            gridMid[x][y] = 259;
          }
        }
      }

      var flatten = function flatten(arr) {
        return arr.reduce(function (acc, el) {
          return [].concat(_toConsumableArray(acc), _toConsumableArray(el));
        }, []);
      };

      var lol = {
        "height": h,
        "width": w,
        "layers": [{
          "data": flatten(grid),
          "height": h,
          "name": "base",
          "opacity": 1,
          "type": "tilelayer",
          "visible": true,
          "width": w,
          "x": 0,
          "y": 0
        }, {
          "data": flatten(gridMid),
          "height": h,
          "name": "mid",
          "opacity": 1,
          "type": "tilelayer",
          "visible": true,
          "width": w,
          "x": 0,
          "y": 0
        }],
        "nextobjectid": 1,
        "orientation": "orthogonal",
        "renderorder": "right-down",
        "tileheight": 32,
        "tilewidth": 32,
        "tilesets": [{
          "columns": 16,
          "firstgid": 1,
          "image": "tiles.png",
          "imageheight": 512,
          "imagewidth": 512,
          "margin": 0,
          "name": "tiles",
          "spacing": 0,
          "tilecount": 256,
          "tileheight": 32,
          "tilewidth": 32
        }, {
          "columns": 16,
          "firstgid": 257,
          "image": "mid.png",
          "imageheight": 512,
          "imagewidth": 512,
          "margin": 0,
          "name": "mid",
          "spacing": 0,
          "tilecount": 256,
          "tileheight": 32,
          "tilewidth": 32
        }],
        "version": 1
      };

      game.load.tilemap("world", null, lol, Phaser.Tilemap.TILED_JSON);

      var map = this.map = game.add.tilemap("world");
      map.addTilesetImage("tiles", "tiles");

      var layer = this.layer = map.createLayer("base");
      map.addTilesetImage("mid", "mid");
      map.createLayer("mid");
      layer.resizeWorld();

      this.grid = this.mapToGrid(map);

      var estar = this.estar = new _easystarjs2.default.js();
      estar.setGrid(this.grid);
      estar.enableDiagonals();
      estar.disableCornerCutting();
      estar.setAcceptableTiles([0, 3]);
    }
  }, {
    key: "mapToGrid",
    value: function mapToGrid(map) {
      var h = map.layers[0].data.length;
      var w = map.layers[0].data[0].length;

      var grid = [];
      for (var y = 0; y < h; y++) {
        var gridRow = [];
        for (var x = 0; x < w; x++) {
          var cell = _BLOCK_TYPE2.default.walkable;
          for (var i = 0; i < map.layers.length; i++) {
            var index = map.layers[i].data[y][x].index;
            var block = _Blocks2.default.getByTileId(index);
            if (!block.walk && !block.mine) {
              cell = _BLOCK_TYPE2.default.solid;
            } else if (block.mine) {
              cell = _BLOCK_TYPE2.default.mineable;
            }
          }
          gridRow.push(cell);
        }
        grid.push(gridRow);
      }
      return grid;
    }
  }, {
    key: "makePath",
    value: function makePath(e, tx, ty, onWalked) {
      var layer = this.layer;
      var xt = layer.getTileX(tx);
      var yt = layer.getTileY(ty);
      if (xt <= -1 || yt <= -1) return;

      var oldx = this.grid[yt][xt];
      this.grid[yt][xt] = _BLOCK_TYPE2.default.tmpwalkable;
      this.estar.setGrid(this.grid);
      this.estar.findPath(e.x / 32 | 0, e.y / 32 | 0, xt, yt, function (path) {
        if (!path) {
          return;
        }
        // TODO: still a bug with this on diagonals
        if (oldx === _BLOCK_TYPE2.default.solid || e instanceof _Player2.default && oldx !== _BLOCK_TYPE2.default.walkable) {
          path = path.slice(0, -1);
        }
        if (path.length === 1 && oldx !== _BLOCK_TYPE2.default.walkable) {
          onWalked && onWalked();
        } else {
          e.setPath(path, onWalked || function () {});
        }
      });
      this.estar.calculate();
      this.grid[yt][xt] = oldx;
    }
  }, {
    key: "findEmptySpot",
    value: function findEmptySpot() {
      var y = null;
      var x = null;
      var spot = -1;

      while (spot !== 0) {
        y = Math.random() * this.map.height | 0;
        x = Math.random() * this.map.width | 0;
        spot = this.grid[y][x];
      }
      return { x: x, y: y };
    }
  }]);

  return Map;
}();

exports.default = Map;

},{"./BLOCK_TYPE":8,"./Blocks":9,"./entities/Player":18,"easystarjs":2,"fast-simplex-noise":5}],15:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var State = function () {
  function State() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";

    _classCallCheck(this, State);

    this.set(state);
  }

  _createClass(State, [{
    key: "set",
    value: function set(state, data) {
      this.last = this.state;
      this.state = state;
      this.count = 0;
      this.time = Date.now();
      this.first = true;
      this.data = data;
    }
  }, {
    key: "isFirst",
    value: function isFirst() {
      var isFirst = this.first;
      this.first = false;
      return isFirst;
    }
  }, {
    key: "get",
    value: function get() {
      return this.state;
    }
  }]);

  return State;
}();

exports.default = State;

},{}],16:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Health = function () {
  function Health(health, maxHealth) {
    _classCallCheck(this, Health);

    this.health = 1;
    this.onDie = null;
    this.onHurt = null;

    this.health = health;
    this.maxHealth = maxHealth;
  }

  _createClass(Health, [{
    key: "damage",
    value: function damage() {
      var amount = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;

      this.health = Math.max(0, this.health - amount);
      this.onHurt && this.onHurt(this.health, this.maxHealth);
      if (this.health <= 0) {
        this.onDie && this.onDie();
      }
      return this.health;
    }
  }]);

  return Health;
}();

exports.default = Health;

},{}],17:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var PathWalker = function () {
  function PathWalker() {
    _classCallCheck(this, PathWalker);

    this.onDone = null;
    this.path = [];
    this.current = null;
    this.last = null;
  }

  _createClass(PathWalker, [{
    key: "setPath",
    value: function setPath(path, onDone) {
      this.path = path;
      if (onDone) {
        this.onDone = onDone;
      }
      this.getCurrent();
    }
  }, {
    key: "getCurrent",
    value: function getCurrent() {
      if (this.current) {
        return this.current;
      }
      return this.next();
    }
  }, {
    key: "next",
    value: function next() {
      this.last = this.current;
      if (!this.path.length) {
        return null;
      }
      this.current = this.path[0];
      this.path = this.path.slice(1);
      return this.current;
    }
  }, {
    key: "update",
    value: function update(atCurrent) {
      if (atCurrent(this.current, this.last)) {
        if (!this.next()) {
          this.onDone();
        }
      }
    }
  }]);

  return PathWalker;
}();

exports.default = PathWalker;

},{}],18:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _State = require("../State");

var _State2 = _interopRequireDefault(_State);

var _Health = require("../components/Health");

var _Health2 = _interopRequireDefault(_Health);

var _PathWalker = require("../components/PathWalker");

var _PathWalker2 = _interopRequireDefault(_PathWalker);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Phaser = window.Phaser;

var Player = function (_Phaser$Sprite) {
  _inherits(Player, _Phaser$Sprite);

  function Player(game, xtile, ytile, onHurt, onDie) {
    _classCallCheck(this, Player);

    var _this = _possibleConstructorReturn(this, (Player.__proto__ || Object.getPrototypeOf(Player)).call(this, game, xtile * 32, ytile * 32, "peeps"));

    _this.walkSpeed = 3;
    _this.hp = 0;
    _this.armour = 0;
    _this.maxArmour = 3;

    game.add.existing(_this);

    _this.state = new _State2.default("idle");
    _this.direction = new _State2.default("right");

    var animSpeed = _this.walkSpeed * 1.5;
    _this.animations.add("walk_right", [0, 1, 2, 1], animSpeed, true);
    _this.animations.add("walk_left", [3, 4, 5, 4], animSpeed, true);
    _this.animations.add("walk_up", [6, 7], animSpeed, true);
    _this.animations.add("walk_down", [8, 9], animSpeed, true);
    _this.animations.add("mine", [10, 11], animSpeed * 2, true);
    _this.animations.add("attack", [12, 13], animSpeed * 2, true);

    _this.health = new _Health2.default(3, 5);
    _this.health.onHurt = onHurt;
    _this.health.onDie = onDie;

    _this.pathWalker = new _PathWalker2.default();
    return _this;
  }

  _createClass(Player, [{
    key: "setPath",
    value: function setPath(path, onDone) {
      var _this2 = this;

      this.pathWalker.setPath(path.slice(1), function () {
        _this2.x = Math.round(_this2.x / 32) * 32;
        _this2.y = Math.round(_this2.y / 32) * 32;
        onDone();
      });
      this.state.set("walking");
    }
  }, {
    key: "switchTool",
    value: function switchTool() {
      // Stop mining if switch tool
      if (this.state.get() === "mining") {
        this.state.set("idle");
      }
    }
  }, {
    key: "mineTile",
    value: function mineTile(block, tile, toolEfficiency, onDone) {
      this.state.set("mining", {
        onMined: onDone,
        toolEfficiency: toolEfficiency,
        hardness: block.hardness
      });
    }
  }, {
    key: "stop",
    value: function stop() {
      this.state.set("idle");
    }
  }, {
    key: "update",
    value: function update() {
      var animations = this.animations;


      var current = this.state.get();
      switch (current) {
        case "walking":
          this.updateExploring();
          break;
        case "mining":
          this.updateMining();
          break;
      }

      if (this.state.isFirst()) {
        var state = this.state.get();
        var dir = this.direction.get();
        if (state === "idle") {
          this.frame = 0;
          animations.stop();
        } else if (state === "walking") {
          animations.play("walk_" + dir);
        } else if (state === "mining") {
          animations.play("mine");
        }
      }
    }
  }, {
    key: "updateMining",
    value: function updateMining() {
      var data = this.state.data;
      var toolEfficiency = data.toolEfficiency;
      var onMined = data.onMined;

      if ((data.hardness -= 0.1 * toolEfficiency) <= 0) {
        onMined();
        this.state.set("idle");
      }
    }
  }, {
    key: "updateExploring",
    value: function updateExploring() {
      var _this3 = this;

      var walkSpeed = this.walkSpeed;
      var pathWalker = this.pathWalker;


      pathWalker.update(function (c, lastPath) {
        if (lastPath) {
          if (c.y !== lastPath.y) {
            _this3.direction.set(c.y < lastPath.y ? "up" : "down");
          } else if (c.x !== lastPath.x) {
            _this3.direction.set(c.x < lastPath.x ? "left" : "right");
          }
        }
        var xo = c.x * 32 - _this3.x;
        var yo = c.y * 32 - _this3.y;

        // TODO: replace this "jittery" path follower with current vs lastPath
        var xx = 0;
        var yy = 0;
        if (Math.abs(xo) >= walkSpeed * 0.65) {
          xx += walkSpeed * Math.sign(xo);
        }
        if (Math.abs(yo) >= walkSpeed * 0.65) {
          yy += walkSpeed * Math.sign(yo);
        }
        if (xx !== 0 && yy !== 0) {
          xx = xx / Math.sqrt(2);
          yy = yy / Math.sqrt(2);
        }
        _this3.x += xx;
        _this3.y += yy;

        return Phaser.Math.distance(_this3.x, _this3.y, c.x * 32, c.y * 32) < walkSpeed;
      });
    }
  }]);

  return Player;
}(Phaser.Sprite);

exports.default = Player;

},{"../State":15,"../components/Health":16,"../components/PathWalker":17}],19:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Phaser = window.Phaser;

var Zombie = function (_Phaser$Sprite) {
  _inherits(Zombie, _Phaser$Sprite);

  function Zombie(game, xtile, ytile) {
    _classCallCheck(this, Zombie);

    var _this = _possibleConstructorReturn(this, (Zombie.__proto__ || Object.getPrototypeOf(Zombie)).call(this, game, xtile * 32, ytile * 32, "peeps"));

    var walkSpeed = 5;
    _this.animations.add("walk_right", [20, 21, 22, 21], walkSpeed, true);
    _this.animations.add("walk_left", [23, 24, 25, 24], walkSpeed, true);
    _this.animations.add("walk_up", [26, 27], walkSpeed, true);
    _this.animations.add("walk_down", [28, 29], walkSpeed, true);

    _this.animations.play("walk_right");

    _this.path = [];
    _this.current = null;
    return _this;
  }

  _createClass(Zombie, [{
    key: "setPath",
    value: function setPath(path, onDone) {
      this.path = path.slice(1);
      this.onDone = onDone;
    }
  }, {
    key: "reset",
    value: function reset(x, y) {
      this.x = x * 32;
      this.y = y * 32;
      this.path = [];
      this.current = null;
      this.onDone && this.onDone();
    }
  }, {
    key: "update",
    value: function update() {
      var current = this.current;
      var path = this.path;
      var animations = this.animations;


      if (!path.length) {
        animations.stop();
      }
      if (!current && path.length) {
        animations.play("walk_down");
        this.current = path[0];
        this.path = path.slice(1);
      }
      var walkSpeed = 1.5;
      if (current) {
        var xo = current.x * 32 - this.x;
        var yo = current.y * 32 - this.y;
        var xx = 0;
        var yy = 0;
        if (Math.abs(xo) >= walkSpeed * 0.65) {
          xx += walkSpeed * Math.sign(xo);
        }
        if (Math.abs(yo) >= walkSpeed * 0.65) {
          yy += walkSpeed * Math.sign(yo);
        }
        if (xx !== 0 && yy !== 0) {
          xx = xx / Math.sqrt(2);
          yy = yy / Math.sqrt(2);
        }
        this.x += xx;
        this.y += yy;

        if (Phaser.Math.distance(this.x, this.y, current.x * 32, current.y * 32) < walkSpeed) {
          this.current = null;
          if (!this.path.length) {
            this.onDone();
            this.x = current.x * 32;
            this.y = current.y * 32;
          }
        }
      }
    }
  }]);

  return Zombie;
}(Phaser.Sprite);

exports.default = Zombie;

},{}],20:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Crafting = function () {
  function Crafting(game, world) {
    var _this = this;

    _classCallCheck(this, Crafting);

    this.world = world;
    var inventory = world.inventory;
    var group = this.group = game.add.group();

    group.create(0, 0, "crafting").fixedToCamera = true;

    var bottomOfTouchable = this.world.inventory.ui.box.cameraOffset.y;
    var craft = group.create(4, bottomOfTouchable + 6, "icons");
    craft.fixedToCamera = true;
    craft.frame = 21;

    var tmpSword = this.tmpSword = group.create(120, 150, "craft-tmp");
    tmpSword.frame = 0;
    tmpSword.alpha = 0.4;
    tmpSword.fixedToCamera = true;
    tmpSword.inputEnabled = true;
    tmpSword.events.onInputDown.add(function () {
      if (inventory.hasItem("wood", 2)) {
        inventory.useItem("wood", 2);
        var slot = inventory.addItem("wood_sword", 4);
        inventory.selectItem(slot.idx, true);
        _this.visible = true;
      }
    }, this);

    var tmpPick = this.tmpPick = group.create(120, 210, "craft-tmp");
    tmpPick.frame = 1;
    tmpPick.alpha = 0.4;
    tmpPick.fixedToCamera = true;
    tmpPick.inputEnabled = true;
    tmpPick.events.onInputDown.add(function () {
      if (inventory.hasItem("wood", 2)) {
        inventory.useItem("wood", 2);
        var slot = inventory.addItem("wood_pick", 4);
        inventory.selectItem(slot.idx, true);
        _this.visible = true;
      }
    }, this);

    var tmpReset = this.tmpReset = group.create(game.width - 120, 10, "craft-tmp");
    tmpReset.frame = 2;
    tmpReset.fixedToCamera = true;
    tmpReset.inputEnabled = true;
    tmpReset.events.onInputDown.add(function () {
      _this.world.reset();
    }, this);

    this.visible = false;
  }

  _createClass(Crafting, [{
    key: "update",
    value: function update(game) {
      var _world = this.world;
      var controls = _world.controls;
      var inventory = _world.inventory;
      var justPressed = controls.justPressed;
      var x = controls.x;
      var y = controls.y;


      if (justPressed) {
        var bottomOfTouchable = inventory.ui.box.cameraOffset.y - 5;
        if (y > bottomOfTouchable) {
          if (x < 50) {
            this.world.setMode("exploring");
            return;
          }
        }

        /*if (y < 200) {
          // Craft!
          if (inventory.hasItem("wood", 2)) {
            inventory.useItem("wood", 2);
            inventory.addItem("wood_pick", 1);
          }
          else {
            // Not enough resources
          }
        }
        */
      }
    }
  }, {
    key: "visible",
    get: function get() {
      return this.group.visible;
    },
    set: function set(visible) {
      this.group.visible = visible;
      if (visible) {
        var inventory = this.world.inventory;

        this.tmpPick.alpha = inventory.hasItem("wood", 2) ? 1 : 0.4;
        this.tmpSword.alpha = inventory.hasItem("wood", 2) ? 1 : 0.4;
      }
    }
  }]);

  return Crafting;
}();

exports.default = Crafting;

},{}],21:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Map = require("../Map");

var _Map2 = _interopRequireDefault(_Map);

var _Controls = require("../Controls");

var _Controls2 = _interopRequireDefault(_Controls);

var _Player = require("../entities/Player");

var _Player2 = _interopRequireDefault(_Player);

var _Inventory = require("../Inventory");

var _Inventory2 = _interopRequireDefault(_Inventory);

var _Zombie = require("../entities/Zombie");

var _Zombie2 = _interopRequireDefault(_Zombie);

var _Blocks = require("../Blocks");

var _Blocks2 = _interopRequireDefault(_Blocks);

var _Items = require("../Items");

var _Items2 = _interopRequireDefault(_Items);

var _Crafting = require("./Crafting");

var _Crafting2 = _interopRequireDefault(_Crafting);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Phaser = window.Phaser;

var World = function (_Phaser$State) {
  _inherits(World, _Phaser$State);

  function World() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, World);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = World.__proto__ || Object.getPrototypeOf(World)).call.apply(_ref, [this].concat(args))), _this), _this.mode = "exploring", _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(World, [{
    key: "preload",
    value: function preload(game) {
      //game.load.tilemap("world", "res/world.json", null, Phaser.Tilemap.TILED_JSON);
      game.load.image("tiles", "res/tiles.png");
      game.load.image("mid", "res/mid.png");
      game.load.image("inventory", "res/inventory.png");
      game.load.image("bmaxFont9", "res/bmax9.png");
      game.load.image("bmaxFont9x4", "res/bmax9x4.png");
      game.load.image("crafting", "res/crafting-back.png");
      game.load.spritesheet("craft-tmp", "res/craft-tmp.png", 34 * 4, 40);
      game.load.spritesheet("peeps", "res/peeps.png", 32, 32);
      game.load.spritesheet("icons", "res/icons.png", 32, 32);
      game.load.spritesheet("icons4x4", "res/icons4x4.png", 16, 16);
      game.load.spritesheet("inv-selection", "res/inv-selection.png", 52, 48);
    }
  }, {
    key: "reset",
    value: function reset() {
      this.mode = "exploring";
      this.game.state.start("World");
    }
  }, {
    key: "create",
    value: function create(game) {
      var _context;

      game.stage.backgroundColor = "#343436";

      this.world = new _Map2.default(game);

      var _world$findEmptySpot = this.world.findEmptySpot();

      var x = _world$findEmptySpot.x;
      var y = _world$findEmptySpot.y;

      this.player = new _Player2.default(game, x, y, this.playerHurt.bind(this), this.playerDied.bind(this));

      this.controls = new _Controls2.default(game);
      this.inventory = new _Inventory2.default(game, (_context = this.player).switchTool.bind(_context));

      var mobs = this.mobs = game.add.group();
      for (var i = 0; i < 4; i++) {
        var _world$findEmptySpot2 = this.world.findEmptySpot();

        var _x = _world$findEmptySpot2.x;
        var _y = _world$findEmptySpot2.y;

        mobs.add(new _Zombie2.default(game, _x, _y));
      }

      var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ .,!?'\":-$                0123456789";
      var title = game.add.retroFont("bmaxFont9x4", 36, 36, chars, 13, 0, 0, 0, 0);
      title.text = "bmax!";
      game.add.image(10, 10, title); //.fixedToCamera = true;

      var subtitle = game.add.retroFont("bmaxFont9", 9, 9, chars, 13, 0, 0, 0, 0);
      subtitle.text = "0123456789!? You bet.";
      game.add.image(4, 36, subtitle).fixedToCamera = true;

      var hearts = this.hearts = game.add.group();

      for (var _i = 0; _i <= 10; _i++) {
        var h = hearts.create(_i * 14 + 4, 4, "icons4x4");
        if (_i >= 3 && _i < 5) h.frame = 1;
        if (_i >= 5) h.frame = 2;
        h.fixedToCamera = true;
      }

      for (var _i2 = 0; _i2 <= 10; _i2++) {
        var _h = hearts.create(_i2 * 14 + 4, 20, "icons4x4");
        if (_i2 <= 2) _h.frame = 17;
        if (_i2 > 2) _h.frame = 18;
        _h.fixedToCamera = true;
      }

      this.craftingScreen = new _Crafting2.default(game, this);

      this.ui = {
        title: title,
        subtitle: subtitle
      };

      game.camera.follow(this.player, Phaser.Camera.FOLLOW_LOCKON, 0.1, 0.1);
    }
  }, {
    key: "playerHurt",
    value: function playerHurt(health, maxHealth) {
      // Update player health ui
      var i = 0;
      this.hearts.forEach(function (h) {
        if (i < health) h.frame = 0;else if (i < maxHealth) h.frame = 1;else if (i < 10) h.frame = 2;
        i++;
      });
    }
  }, {
    key: "playerDied",
    value: function playerDied() {
      this.reset();
    }
  }, {
    key: "onPathWalked",
    value: function onPathWalked(xt, yt) {
      var _this2 = this;

      var ui = this.ui;
      var world = this.world;
      var player = this.player;
      var mobs = this.mobs;

      ui.subtitle.text = xt + "," + yt;

      var tile = world.map.layers[1].data[yt][xt];
      var block = _Blocks2.default.getByTileId(tile.index);
      if (block.mine) {
        var _ret2 = function () {
          // Closest zombie chase player
          var done = false;
          mobs.forEach(function (m) {
            if (done) return;
            var dist = Phaser.Math.distance(m.x, m.y, player.x, player.y);
            if (dist < 300) {
              done = true;
              world.makePath(m, player.x, player.y);
            }
          });

          var tool = _this2.inventory.holding();
          var toolEfficiency = _Items2.default[tool.item].efficiency || 1;
          if (_Items2.default[tool.item].damage) {
            // Can't mine with a weapon.
            player.stop();
            return {
              v: void 0
            };
          }
          // TODO: handle nicer: player -> tool -> target block
          player.mineTile(block, tile, toolEfficiency, function () {
            world.grid[yt][xt] = 0;
            world.map.putTile(_Blocks2.default.clear.tile, xt, yt, 1);
            block.yields.forEach(function (_ref2) {
              var name = _ref2.name;
              var amount = _ref2.amount;

              _this2.inventory.addItem(name, amount);
            });
            if (toolEfficiency > 1) {
              tool.addItem(-1);
            }
          });
        }();

        if ((typeof _ret2 === "undefined" ? "undefined" : _typeof(_ret2)) === "object") return _ret2.v;
      } else {
        player.stop();
      }
    }
  }, {
    key: "setMode",
    value: function setMode(mode) {
      this.mode = mode;
      var isCrafting = this.mode == "crafting";
      this.craftingScreen.visible = isCrafting;
    }
  }, {
    key: "update",
    value: function update(game) {
      var _this3 = this;

      var mode = this.mode;
      var player = this.player;
      var mobs = this.mobs;
      var controls = this.controls;

      controls.update();
      switch (mode) {
        case "exploring":
          this.updateExploring(game);
          break;
        case "crafting":
          this.craftingScreen.update(game);
          break;
      }

      // Collision detect
      mobs.forEach(function (m) {
        var dist = Phaser.Math.distance(m.x, m.y, player.x, player.y);
        if (dist < 60) {
          var holding = _this3.inventory.holding();
          var damage = _Items2.default[holding.item].damage;
          if (damage) {
            player.animations.play("attack");
          }
          if (dist < 32) {
            m.y -= 64; // "knockback"
            if (damage) {
              // kill zombie
              var _world$findEmptySpot3 = _this3.world.findEmptySpot();

              var x = _world$findEmptySpot3.x;
              var y = _world$findEmptySpot3.y;

              m.reset(x, y);
              player.state.set("idle");
              holding.addItem(-1);
            } else {
              player.health.damage(1);
            }
          }
        }
      });

      // Randomly run towards player
      if (Math.random() < 0.005) {
        var mob = mobs.getRandom();
        this.world.makePath(mob, player.x, player.y);
      }
    }
  }, {
    key: "updateExploring",
    value: function updateExploring(game) {
      var _this4 = this;

      var controls = this.controls;
      var inventory = this.inventory;
      var justPressed = controls.justPressed;
      var x = controls.x;
      var y = controls.y;
      var worldX = controls.worldX;
      var worldY = controls.worldY;


      if (justPressed) {
        var bottomOfTouchable = inventory.ui.box.cameraOffset.y - 5;
        if (y > bottomOfTouchable) {
          if (x < game.width - 45) {
            if (x < 50) {
              this.setMode("crafting");
            }
            return;
          }
        }

        // Walk to spot
        this.world.makePath(this.player, worldX, worldY, function () {
          _this4.onPathWalked(worldX / 32 | 0, worldY / 32 | 0);
        });
      }
    }
  }]);

  return World;
}(Phaser.State);

exports.default = World;

},{"../Blocks":9,"../Controls":10,"../Inventory":12,"../Items":13,"../Map":14,"../entities/Player":18,"../entities/Zombie":19,"./Crafting":20}]},{},[1]);
