# never, no never

* [bug] fix directions
* [ref] convert World "mode" to state
* [bug] use up items when placed
* [bug] places blocks while in the air
* [bug] pathfinding recalc on player goes wrong way
* [bug] baddies stuck
* [bug] remove player shadow when flying
* less visible target cursor when on mineable block
* auto-switch tools when mining/attacked
* one-up on floppy get
* mining particles
* attack particles
* floppies per day
* zombie roaming state
* roam on player death
* drops from mining
* drops from zombie kills
* find a recipe, unlock
* add death screen (or modal)
* store progress/stats/unlocks
  * on died, show progress hp
  * on died, "surived for" time.
* reset unlocks for testing
* stats on splash
* Move blocks and items from flyweight to actual objects
  * cellular autonoma ability
  * show un-obtained resources in crafting.
* system for player -> tool -> target block
* [ref] fix state machine: don't allow bad states
* clouds float overhead
* [bug] invalidate/recalc paths on build, destroy.
* [bug] Errors when destroying particle emitters after screen swap
