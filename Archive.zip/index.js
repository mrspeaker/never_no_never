import Game from "./src/Game";
new Game();
