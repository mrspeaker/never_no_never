const BLOCK_TYPE = {
  walkable: 0,
  solid: 1,
  mineable: 2,
  tmpwalkable: 3
};

export default BLOCK_TYPE;
